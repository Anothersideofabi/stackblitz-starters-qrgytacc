const books = {}; // Tambahkan titik koma

function getBooks() {
  return books; // Indentasi 2 spasi
}

function getBookById(id) {
  const book = books[id]; // 'let' diubah menjadi 'const', tambahkan titik koma

  if (!book) {
    return null; // Indentasi 4 spasi (sesuai feedback untuk baris 11), tambahkan titik koma
  }

  return book.id; // Indentasi 2 spasi, tambahkan titik koma
}

function saveBook(book) {
  books[book.id] = book; // Indentasi 2 spasi, tambahkan titik koma
}

saveBook({ id: 'book-1', name: 'Book 1' }); // Tambahkan spasi setelah { dan sebelum }, tambahkan titik koma
const myBooks = getBooks(); // 'let' diubah menjadi 'const', tambahkan titik koma
const myBook = getBookById('book-1'); // Tambahkan titik koma

console.log(myBooks); // Tambahkan titik koma
console.log(myBook); // Tambahkan titik koma